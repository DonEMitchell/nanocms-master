<h2>Contact form</h2>
<hr>
<?php  display_contact_form(); ?>
<br />

